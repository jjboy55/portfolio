var canvas = document.getElementsByTagName('canvas')[0];

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

var context = canvas.getContext('2d');

/*context.beginPath();
context.fillStyle = 'rgb(255,10,10)';
context.fillRect(200,100,400,400);*/

/*context.beginPath();
context.moveTo(400,100);
context.lineTo(700,300);
context.lineTo(700, 20);
context.lineTo(400,100);
context.fill();*/
const colors = ["green", "blue", "yellow", "orange", "red", "brown"];
var y = canvas.height/4;
var x = canvas.width/2;
var radius = 10;
const gravity = 1;
const friction = 0.9744;
var dx = 5;
var dy = 5;
function animateBall(){
    //context.clearRect(0,0,canvas.width,canvas.height);
    context.beginPath();
    context.arc(x,y, radius, 0, Math.PI * 2, false);
    context.fill();

    if((x+radius > canvas.width) || (x - radius < 0))
    {
        dx = (-dx*friction);
        context.fillStyle = colors[Math.ceil(Math.random()*(colors.length-1))];
    }

    if((y+radius > canvas.height))
    {
        dy = (-dy*friction);
        context.fillStyle = colors[Math.ceil(Math.random()*(colors.length-1))];
    }else{
        dy += gravity;
    }
    
    y+=dy;
    x+=dx;
    requestAnimationFrame(animateBall);
}

animateBall();