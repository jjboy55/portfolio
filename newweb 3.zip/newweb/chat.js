const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const monthNames = ["Jan", "Feb", "Mar", "Apr", 
"May", "Jun", "Jul", "Aug","Sep", "Oct", "Nov", "Dec"];
function generateMessage(){
    var message = document.getElementById('chat_text').value;
    if(message != "")
    {
        var sendContainer = document.createElement('div');
        var senderBubble = document.createElement('div');
        sendContainer.className = 'sender_container';
        senderBubble.className = 'sender_bubble';
        senderBubble.innerText = message;
        var time = document.createElement('h4');
        var date = new Date();
        var month = date.getMonth();
        var day = date.getDay();
        var hour = date.getHours();
        var minute = date.getMinutes();
        time.style.marginRight = "20px";
        time.innerText = monthNames[month]+" "+days[day]+" "+hour+":"+minute;
        sendContainer.appendChild(senderBubble);
        sendContainer.appendChild(time);
        document.getElementById('chat_box').appendChild(sendContainer);
        document.getElementById('chat_box').lastChild.scrollIntoView({
            block:"end",
            behavior:"smooth"
        });
        document.getElementById('chat_text').value = "";
    }
}

function sendMessage(event){
    if(event.key === "Enter"){
        generateMessage();
    }
}

function scrollElement(){
    var ai = document.getElementById('ai');
    ai.scrollIntoView({
        block:"start",
        behavior:"smooth"
    });
}